#!/usr/bin/env python

"""Tests for `cba_search` package."""


import unittest

from cba_search import cba_search


class TestCba_search(unittest.TestCase):
    """Tests for `cba_search` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""

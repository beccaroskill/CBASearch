=====
Usage
=====

To use CBA Search in a project::

    import cba_search

"""Top-level package for CBA Search."""

__author__ = """Becca Roskill"""
__email__ = 'beccaroskill@gmail.com'
__version__ = '0.1.0'
